using System;

namespace Sum {
    public class Addition {
        public static int Add(int op1, int op2) {
            return op1 + op2;
        }
    }
}