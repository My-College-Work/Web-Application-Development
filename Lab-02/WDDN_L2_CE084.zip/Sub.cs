using System;

namespace Sub {
    public class Subtract {
        public static int Minus(int op1, int op2) {
            return op1 - op2;
        }
    }
}